//
//  ResultView.swift
//  LoveLanguage
//
//  Created by Makape Tema on 2025/01/19.
//

//import SwiftUI

//struct ResultView: View {
//    let result: LoveLanguage?
//    let resetAction: () -> Void
//
//    var body: some View {
//        VStack(spacing: 20) {
//            Text("Your Love Language")
//                .font(.largeTitle)
//                .fontWeight(.bold)
//
//            if let result = result {
//                Text(result.rawValue)
//                    .font(.title)
//                    .padding()
//            } else {
//                Text("No result found.")
//                    .font(.title)
//                    .padding()
//            }
//
//            Button(action: resetAction) {
//                Text("Restart Quiz")
//                    .padding()
//                    .background(Color.green)
//                    .foregroundColor(.white)
//                    .cornerRadius(8)
//            }
//        }
//        .padding()
//    }
//}

import SwiftUI

struct ResultView: View {
    let dominantLoveLanguage: LoveLanguage?
    
    var body: some View {
        VStack {
            if let loveLanguage = dominantLoveLanguage {
                Text("Your Dominant Love Language:")
                    .font(.title)
                    .padding()
                
                Text(loveLanguage.rawValue)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                    .padding()
                
                Text("This love language reflects how you give and receive love most naturally. Understanding it can help improve your relationships.")
                    .multilineTextAlignment(.center)
                    .padding()
            } else {
                Text("No dominant love language detected.")
                    .font(.title2)
                    .padding()
            }
            
            Spacer()
            
            Button("Retake Quiz") {
                // Logic to reset the quiz can go here
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
        }
        .padding()
        .navigationTitle("Result")
    }
}

#Preview {
    ResultView(dominantLoveLanguage: .physicalTouch)
}

