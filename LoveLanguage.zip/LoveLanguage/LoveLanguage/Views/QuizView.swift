//
//  QuizView.swift
//  LoveLanguage
//
//  Created by Makape Tema on 2025/01/19.
//

//import SwiftUI

//struct QuizView: View {
//    @StateObject private var viewModel = QuizViewModel()
//
//    var body: some View {
//        if viewModel.showResult {
//            ResultView(result: viewModel.result, resetAction: viewModel.resetQuiz)
//        } else {
//            QuestionView(
//                question: viewModel.questions[viewModel.currentQuestionIndex],
//                onAnswerSelected: viewModel.selectAnswer
//            )
//        }
//    }
//}
import SwiftUI

struct QuizView: View {
    @StateObject private var viewModel = QuizViewModel()
    @State private var path: [LoveLanguage?] = []

    var body: some View {
        if #available(iOS 16.0, *) {
            NavigationStack(path: $path) {
                VStack(spacing: 20) {
                    // Progress Indicator
                    ProgressView(value: Double(viewModel.currentQuestionIndex + 1), total: Double(viewModel.questions.count))
                        .progressViewStyle(LinearProgressViewStyle(tint: Color.pink))
                        .padding(.horizontal)
                    
                    // Question Text
                    Text(viewModel.currentQuestion.text)
                        .font(.title2)
                        .fontWeight(.semibold)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                    
                    // Answer Buttons
                    VStack(spacing: 16) {
                        ForEach(viewModel.currentQuestion.answers, id: \.text) { answer in
                            Button(action: {
                                withAnimation {
                                    viewModel.selectAnswer(answer)
                                    if viewModel.showResult {
                                        path.append(viewModel.dominantLoveLanguage)
                                    }
                                }
                            }) {
                                Text(answer.text)
                                    .fontWeight(.medium)
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(LinearGradient(
                                        colors: [Color.blue, Color.purple],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ))
                                    .cornerRadius(12)
                                    .shadow(color: Color.purple.opacity(0.3), radius: 6, x: 0, y: 4)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal)
                }
                .padding()
                .background(
                    LinearGradient(
                        colors: [Color.pink.opacity(0.6), Color.purple.opacity(0.8)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea()
                )
                .navigationDestination(for: LoveLanguage?.self) { loveLanguage in
                    ResultView(dominantLoveLanguage: loveLanguage)
                }
                .navigationTitle("Love Language Quiz")
                .foregroundColor(.white)
            }
        } else {
            // Fallback on earlier versions
        }
    }
}

#Preview {
    QuizView()
}
