//
//  QuestionsData.swift
//  LoveLanguage
//
//  Created by Makape Tema on 2025/01/19.
//

import Foundation

let wordsOfAffirmationQuestions: [Question] = [
    Question(
        text: "How do you feel when someone expresses pride in your achievements?",
        answers: [
            Answer(text: "It motivates me to keep achieving.", loveLanguage: .wordsOfAffirmation),
            Answer(text: "I appreciate it, but actions mean more to me.", loveLanguage: .actsOfService),
            Answer(text: "It’s nice, but spending time with them matters more.", loveLanguage: .qualityTime)
        ]
    ),
    Question(
        text: "Do compliments or kind words make your day better? If so, how?",
        answers: [
            Answer(text: "Yes, they boost my confidence and make me feel appreciated.", loveLanguage: .wordsOfAffirmation),
            Answer(text: "Sometimes, but I value quality time more.", loveLanguage: .qualityTime),
            Answer(text: "Not really, I prefer physical gestures like hugs.", loveLanguage: .physicalTouch)
        ]
    )
    // Add more questions here
]

let qualityTimeQuestions: [Question] = [
    Question(
        text: "How do you feel when someone cancels plans at the last minute?",
        answers: [
            Answer(text: "It bothers me because spending time together is important.", loveLanguage: .qualityTime),
            Answer(text: "It’s fine if they make it up with an act of service.", loveLanguage: .actsOfService),
            Answer(text: "I’d appreciate a heartfelt apology instead.", loveLanguage: .wordsOfAffirmation)
        ]
    ),
    Question(
        text: "Would you prefer spending a whole day with someone over receiving a gift?",
        answers: [
            Answer(text: "Yes, I value the time spent together.", loveLanguage: .qualityTime),
            Answer(text: "Not necessarily, a thoughtful gift shows love too.", loveLanguage: .receivingGifts),
            Answer(text: "I’d rather they do something helpful for me.", loveLanguage: .actsOfService)
        ]
    )
    // Add more questions here
]

let physicalTouchQuestions: [Question] = [
    Question(
        text: "Do you feel more connected to people when they hug or touch you?",
        answers: [
            Answer(text: "Yes, physical touch is how I feel most loved.", loveLanguage: .physicalTouch),
            Answer(text: "Not necessarily, kind words matter more to me.", loveLanguage: .wordsOfAffirmation),
            Answer(text: "I value spending quality time more.", loveLanguage: .qualityTime)
        ]
    ),
    Question(
        text: "How do you feel when someone avoids physical affection?",
        answers: [
            Answer(text: "It makes me feel disconnected.", loveLanguage: .physicalTouch),
            Answer(text: "I understand, as long as they express love in other ways.", loveLanguage: .actsOfService),
            Answer(text: "It doesn’t bother me as much if we still spend time together.", loveLanguage: .qualityTime)
        ]
    )
    // Add more questions here
]

let actsOfServiceQuestions: [Question] = [
    Question(
        text: "How do you feel when someone helps you with a chore or task you’ve been struggling with?",
        answers: [
            Answer(text: "It makes me feel truly cared for.", loveLanguage: .actsOfService),
            Answer(text: "I appreciate it, but I’d rather they spend time with me.", loveLanguage: .qualityTime),
            Answer(text: "I’d prefer they say kind words of encouragement.", loveLanguage: .wordsOfAffirmation)
        ]
    ),
    Question(
        text: "Do you appreciate it when someone runs errands or handles responsibilities for you?",
        answers: [
            Answer(text: "Yes, it feels like a weight off my shoulders.", loveLanguage: .actsOfService),
            Answer(text: "I’d rather spend that time with them.", loveLanguage: .qualityTime),
            Answer(text: "I’d appreciate a thoughtful gift instead.", loveLanguage: .receivingGifts)
        ]
    )
    // Add more questions here
]

let receivingGiftsQuestions: [Question] = [
    Question(
        text: "Do you feel loved when someone surprises you with a gift, even if it’s small?",
        answers: [
            Answer(text: "Yes, it shows they were thinking of me.", loveLanguage: .receivingGifts),
            Answer(text: "I’d prefer spending time together instead.", loveLanguage: .qualityTime),
            Answer(text: "No, I value words of appreciation more.", loveLanguage: .wordsOfAffirmation)
        ]
    ),
    Question(
        text: "Does the thought behind a gift matter more to you than its monetary value?",
        answers: [
            Answer(text: "Yes, the meaning behind the gift is what counts.", loveLanguage: .receivingGifts),
            Answer(text: "Not really, actions like helping me mean more.", loveLanguage: .actsOfService),
            Answer(text: "I’d rather hear kind words instead of receiving a gift.", loveLanguage: .wordsOfAffirmation)
        ]
    )
    // Add more questions here
]

//let allQuestions: [Question] = wordsOfAffirmationQuestions
//    + qualityTimeQuestions
//    + physicalTouchQuestions
//    + actsOfServiceQuestions
//    + receivingGiftsQuestions


