//
//  Model.swift
//  LoveLanguage
//
//  Created by Makape Tema on 2025/01/19.
//

struct Question {
    let text: String
    let answers: [Answer]
}

struct Answer {
    let text: String
    let loveLanguage: LoveLanguage
}

enum LoveLanguage: String {
    case wordsOfAffirmation = "Words of Affirmation"
    case qualityTime = "Quality Time"
    case physicalTouch = "Physical Touch"
    case actsOfService = "Acts of Service"
    case receivingGifts = "Receiving Gifts"
}
