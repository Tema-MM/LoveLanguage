//
//  LoveLanguageApp.swift
//  LoveLanguage
//
//  Created by Makape Tema on 2025/01/19.
//

import SwiftUI

@main
struct LoveLanguageApp: App {
    var body: some Scene {
        WindowGroup {
            QuizView()
        }
    }
}
