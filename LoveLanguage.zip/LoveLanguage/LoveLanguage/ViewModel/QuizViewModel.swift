//
//  QuizViewModel.swift
//  LoveLanguage
//
//  Created by Makape Tema on 2025/01/19.
//

import Foundation
import SwiftUI
//
//class QuizViewModel: ObservableObject {
//    @Published var questions: [Question] = []
//    @Published var currentQuestionIndex: Int = 0
//    @Published var scores: [LoveLanguage: Int] = [:]
//    @Published var showResult = false
//
//    init() {
//        loadQuestions()
//    }
//
//    func loadQuestions() {
//        questions = [
//            Question(
//                text: "How do you feel most loved?",
//                answers: [
//                    Answer(text: "When someone tells me how much they appreciate me.", loveLanguage: .wordsOfAffirmation),
//                    Answer(text: "When someone spends quality time with me.", loveLanguage: .qualityTime),
//                    Answer(text: "When someone gives me a big hug.", loveLanguage: .physicalTouch),
//                    Answer(text: "When someone helps me with a task.", loveLanguage: .actsOfService),
//                    Answer(text: "When someone surprises me with a thoughtful gift.", loveLanguage: .receivingGifts)
//                ]
//            ),
//            // Add more questions here
//        ]
//    }
//
//    func selectAnswer(_ answer: Answer) {
//        scores[answer.loveLanguage, default: 0] += 1
//        if currentQuestionIndex < questions.count - 1 {
//            currentQuestionIndex += 1
//        } else {
//            showResult = true
//        }
//    }
//
//    func resetQuiz() {
//        currentQuestionIndex = 0
//        scores = [:]
//        showResult = false
//    }
//
//    var result: LoveLanguage? {
//        scores.max(by: { $0.value < $1.value })?.key
//    }
//}

class QuizViewModel: ObservableObject {
    @Published var currentQuestionIndex: Int = 0
    @Published var selectedAnswers: [Answer] = []
    @Published var showResult: Bool = false
    @Published var dominantLoveLanguage: LoveLanguage? = nil

    let questions: [Question] = wordsOfAffirmationQuestions
        + qualityTimeQuestions
        + physicalTouchQuestions
        + actsOfServiceQuestions
        + receivingGiftsQuestions

    var currentQuestion: Question {
        questions[currentQuestionIndex]
    }

    func selectAnswer(_ answer: Answer) {
        selectedAnswers.append(answer)
        if currentQuestionIndex < questions.count - 1 {
            currentQuestionIndex += 1
        } else {
            calculateLoveLanguage()
            showResult = true
        }
    }

    private func calculateLoveLanguage() {
        let counts = selectedAnswers.reduce(into: [LoveLanguage: Int]()) { result, answer in
            result[answer.loveLanguage, default: 0] += 1
        }
        dominantLoveLanguage = counts.max { $0.value < $1.value }?.key
    }
}
