//
//  LoveLanguageTests.swift
//  LoveLanguageTests
//
//  Created by Makape Tema on 2025/01/19.
//

import Testing
@testable import LoveLanguage

struct LoveLanguageTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
